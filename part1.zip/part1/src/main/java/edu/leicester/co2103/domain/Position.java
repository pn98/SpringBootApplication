package edu.leicester.co2103.domain;

public enum Position {
	GTA, LECTURER, PROFESSOR;
}
